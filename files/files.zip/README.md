# Witness: a Meta model finds the proof, Lean checks it

Finding a proof is hard; checking one is easy. That gap is the heart of **P vs NP**.
Witness lets **Muse Spark** search for proofs and accepts only what the **Lean 4** proof
checker verifies. When Lean rejects a proof, its exact error goes back to the model to repair it.

## How it works

1. **Find:** Muse Spark (or Muse Wonder) gets a theorem and writes a proof.
2. **Check:** Lean compiles it. Lean never trusts the model.
3. **Repair:** on failure, Lean's error is sent back for another attempt (up to 5).
4. **No cheating:** proofs using `sorry`, `axiom`, `native_decide`, etc. are rejected automatically.

## Benchmark (15 theorems, core Lean 4, no Mathlib)

- **Warm-up (10):** arithmetic, lists, logic.
- **Find the certificate (5):** NP-style puzzles: SAT, perfect square, two numbers, subset sum,
  graph 3-coloring. The model must find a witness; Lean checks it instantly.

## Results

<!-- Fill in from `python prover.py summary` after running the benchmark. -->
| Model | Verified | Pass rate | Avg attempts | Tokens | Cost |
|---|---|---|---|---|---|
| Muse Spark 1.3 |  |  |  |  |  |
| Muse Wonder 1.0 |  |  |  |  |  |

## Meta AI used

- **Muse Spark 1.3** (Meta Model API): main prover
- **Muse Wonder 1.0** (Meta Model API): comparison on the same benchmark
- **Muse Code**: <!-- describe honestly what you built with it -->

## Run it

**1. Install Lean 4** (open a new terminal afterwards so `lean` is on your PATH)

- macOS / Linux / Git Bash:
  `curl https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh -sSf | sh`
- Windows PowerShell:
  ```
  curl -O --location https://raw.githubusercontent.com/leanprover/elan/master/elan-init.ps1
  powershell -ExecutionPolicy Bypass -f elan-init.ps1
  ```

**2. Install Python packages**
```
pip install -r requirements.txt
```

**3. Check Lean works (no API key needed)**
```
python prover.py selftest        # expect 15/15 reference proofs verified
```

**4. Set your Meta Model API key**
```
export MODEL_API_KEY=your_key            # macOS / Linux / Git Bash
$env:MODEL_API_KEY="your_key"            # Windows PowerShell
```

**5. Prove things**
```
python prover.py prove two_numbers
python prover.py bench --model muse-spark-1.3
python prover.py bench --model muse-wonder-1.0
python prover.py summary
streamlit run app.py
```

## Built during the Meta Global AI Developer Hackathon (Oct 26 – Nov 4, 2026)

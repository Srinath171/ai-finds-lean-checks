"""Witness demo app.  Run:  streamlit run app.py"""
import os
import time

import pandas as pd
import streamlit as st

import prover

st.set_page_config(page_title="Witness", page_icon="✓", layout="wide")

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Literata:opsz,wght@7..72,500;7..72,700&display=swap');
:root { --ink:#172033; --rule:#D9E1EC; --ok:#16794A; --bad:#B3261E; --muted:#5B6578; }
h1, .hero { font-family:'Literata', Georgia, serif; color:var(--ink); }
.hero { font-size:2.4rem; line-height:1.15; font-weight:700; margin:0 0 .3rem 0; max-width:22ch; }
.sub { color:var(--muted); font-size:1.05rem; max-width:60ch; margin-bottom:1.2rem; }
.row { border-left:4px solid var(--rule); padding:.4rem .9rem; margin:.6rem 0; }
.row.ok { border-color:var(--ok); }
.row.bad { border-color:var(--bad); }
.verdict.ok { color:var(--ok); font-weight:700; }
.verdict.bad { color:var(--bad); font-weight:700; }
</style>
""", unsafe_allow_html=True)

MODELS = {
    "Muse Spark 1.3": "muse-spark-1.3",
    "Muse Wonder 1.0": "muse-wonder-1.0",
    "Offline check (reference proofs, no API)": "reference",
}

theorems = prover.load_theorems()

with st.sidebar:
    st.subheader("Settings")
    model_label = st.radio("Model that finds the proof", list(MODELS))
    model = MODELS[model_label]
    attempts = st.slider("Attempts before giving up", 1, 8, 5)
    if model != "reference" and not os.environ.get("MODEL_API_KEY"):
        st.error("MODEL_API_KEY is not set. Set it in your terminal, then restart the app.")
    st.caption("Lean checks every proof. A proof counts only if Lean accepts it.")

st.markdown('<p class="hero">A Meta model finds the proof. Lean checks it.</p>', unsafe_allow_html=True)
st.markdown('<p class="sub">Finding a proof is hard; checking one is easy. That gap is the heart of '
            'P vs NP. Witness lets Muse Spark search, and only accepts what the Lean proof '
            'checker verifies.</p>', unsafe_allow_html=True)

tab_prove, tab_bench, tab_how = st.tabs(["Prove a theorem", "Benchmark", "How it works"])


def attempt_block(container, r):
    css = "ok" if r["verified"] else "bad"
    verdict = "Verified by Lean" if r["verified"] else "Rejected by Lean"
    with container:
        st.markdown(f'<div class="row {css}"><span class="verdict {css}">Attempt {r["attempt"]}: '
                    f'{verdict}</span> <span style="color:#5B6578">({r["seconds"]}s)</span></div>',
                    unsafe_allow_html=True)
        st.code(r["proof"] or "(empty)", language=None)
        if not r["verified"]:
            with st.expander("What Lean said"):
                st.code(r["lean_output"], language=None)


with tab_prove:
    labels = {f'{t["name"]}  ({t["group"]})': t for t in theorems}
    choice = st.selectbox("Theorem", list(labels))
    theorem = labels[choice]
    st.code(f'theorem {theorem["name"]} {theorem["statement"]}', language=None)
    if st.button("Find a proof", type="primary"):
        feed = st.container()
        with st.spinner(f"{model_label} is searching…"):
            try:
                result = prover.prove(theorem, model, attempts,
                                      on_attempt=lambda r: attempt_block(feed, r))
            except SystemExit as e:
                st.error(str(e))
                st.stop()
            except Exception as e:  # API or network problem
                st.error(f"The model call failed: {e}")
                st.stop()
        if result["verified"]:
            cost = "" if result["cost"] is None else f", cost ${result['cost']:.4f}"
            st.success(f"Verified by Lean in {result['attempts']} attempt(s){cost}.")
        else:
            st.warning(f"No verified proof after {result['attempts']} attempts. "
                       "Try more attempts or Muse Wonder.")

with tab_bench:
    st.write(f"Run all {len(theorems)} theorems with the model chosen in the sidebar, "
             "then compare models in the table.")
    if st.button(f"Run all {len(theorems)} theorems with {model_label}"):
        bar = st.progress(0.0)
        run_id = time.strftime("%Y%m%d-%H%M%S")
        for i, t in enumerate(theorems, start=1):
            try:
                prover.prove(t, model, attempts, run_id=run_id)
            except Exception as e:
                st.error(f"{t['name']}: {e}")
                break
            bar.progress(i / len(theorems), text=f"{i}/{len(theorems)}: {t['name']}")
    rows = prover.summarize()
    if rows:
        st.subheader("Results by model")
        st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")
    else:
        st.info("No results yet. Run the benchmark to fill this table.")

with tab_how:
    st.markdown("""
1. **Find:** the Meta model gets the theorem and writes a proof.
2. **Check:** Lean, a proof checker, compiles it. Lean never trusts the model.
3. **Repair:** if Lean rejects the proof, its exact error goes back to the model for another try.
4. **Trust only Lean:** proofs using `sorry`, `axiom`, or `native_decide` are rejected automatically.

The *Find the certificate* theorems mirror NP problems (SAT, subset sum, graph coloring):
the model must find a witness, and Lean checks it instantly.
""")

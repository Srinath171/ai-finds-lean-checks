"""Witness: a Meta model finds the proof, Lean checks it.

Usage:
  python prover.py selftest                          # checks your Lean install (no API needed)
  python prover.py prove sat_instance                # one theorem with the default model
  python prover.py bench --model muse-spark-1.3      # all theorems
  python prover.py bench --model muse-wonder-1.0
  python prover.py summary                           # pass rate / attempts / cost per model

Environment:
  MODEL_API_KEY   your Meta Model API key (required for real models)
  META_BASE_URL   default https://api.meta.ai/v1
  LEAN_CMD        default "lean" (set to a full path if lean is not on PATH)
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).parent
THEOREMS_FILE = ROOT / "theorems.json"
RESULTS_FILE = ROOT / "results" / "attempts.jsonl"
DEFAULT_MODEL = "muse-spark-1.3"

# USD per 1M tokens (input, output). Muse Wonder's rate is published; fill in
# Muse Spark's from your Model API dashboard. None = cost not shown.
PRICES = {
    "muse-wonder-1.0": (4.0, 20.0),
    "muse-spark-1.3": None,
}

# A proof containing any of these is rejected before Lean even runs.
FORBIDDEN = ["sorry", "admit", "axiom", "native_decide", "implemented_by",
             "extern", "unsafe", "#exit", "set_option", "import", "macro", "elab"]

SYSTEM_PROMPT = """You are an expert Lean 4 prover. You will be given one theorem.
Return ONLY the proof that goes after `:=` and nothing else.
Rules:
- Core Lean 4 only. No Mathlib, no imports.
- Never use sorry, admit, axiom, or native_decide.
- Do not restate the theorem and do not use markdown.
- Useful tactics: omega, simp, decide, rfl, cases, induction, constructor, exact.
- For existential statements, give the witness explicitly, e.g. ⟨3, 7, by decide⟩ or ⟨true, false, rfl⟩."""


def load_theorems() -> list[dict]:
    return json.loads(THEOREMS_FILE.read_text(encoding="utf-8"))


def get_theorem(name: str) -> dict:
    for t in load_theorems():
        if t["name"] == name:
            return t
    raise SystemExit(f"Unknown theorem: {name}")


def lean_source(theorem: dict, proof: str) -> str:
    return f"theorem {theorem['name']} {theorem['statement']} :=\n  {proof}\n"


def clean_proof(text: str) -> str:
    """Turn a model reply into just the proof body."""
    text = text.strip()
    fence = re.search(r"```(?:lean4?|)\s*\n(.*?)```", text, re.S)
    if fence:
        text = fence.group(1).strip()
    if re.match(r"^(theorem|lemma|example)\b", text):
        _, _, after = text.partition(":=")
        text = after.strip()
    if text.startswith(":="):
        text = text[2:].strip()
    return text


def check_with_lean(theorem: dict, proof: str, timeout: int = 60) -> tuple[bool, str]:
    """Return (verified, lean_output)."""
    lowered = proof.lower()
    for word in FORBIDDEN:
        if re.search(rf"(^|[^a-z_]){re.escape(word)}([^a-z_]|$)", lowered):
            return False, f"Rejected before checking: proof uses forbidden keyword '{word}'."
    if not proof:
        return False, "Rejected: empty proof."

    lean_cmd = os.environ.get("LEAN_CMD", "lean")
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "Check.lean"
        path.write_text(lean_source(theorem, proof), encoding="utf-8")
        try:
            run = subprocess.run([lean_cmd, str(path)], capture_output=True, text=True,
                                 encoding="utf-8", errors="replace", timeout=timeout)
        except FileNotFoundError:
            return False, f"Lean not found. Install Lean 4 or set LEAN_CMD (tried '{lean_cmd}')."
        except subprocess.TimeoutExpired:
            return False, f"Lean timed out after {timeout}s."
    output = (run.stdout + run.stderr).replace(str(path), "Check.lean").strip()
    verified = run.returncode == 0 and "sorry" not in output
    return verified, output or "No errors."


def ask_model(client, model: str, messages: list[dict]) -> tuple[str, dict]:
    response = client.chat.completions.create(model=model, messages=messages)
    text = response.choices[0].message.content or ""
    usage = getattr(response, "usage", None)
    tokens = {
        "input": getattr(usage, "prompt_tokens", 0) or 0,
        "output": getattr(usage, "completion_tokens", 0) or 0,
    }
    return text, tokens


def cost_of(model: str, tokens: dict) -> float | None:
    price = PRICES.get(model)
    if not price:
        return None
    return tokens["input"] / 1e6 * price[0] + tokens["output"] / 1e6 * price[1]


def make_client():
    from openai import OpenAI
    key = os.environ.get("MODEL_API_KEY")
    if not key:
        raise SystemExit("Set MODEL_API_KEY to your Meta Model API key first.")
    return OpenAI(api_key=key, base_url=os.environ.get("META_BASE_URL", "https://api.meta.ai/v1"))


def log(record: dict) -> None:
    RESULTS_FILE.parent.mkdir(exist_ok=True)
    with RESULTS_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def prove(theorem: dict, model: str = DEFAULT_MODEL, max_attempts: int = 5,
          client=None, on_attempt=None, run_id: str | None = None) -> dict:
    """Find-and-check loop. Calls on_attempt(record) after every attempt."""
    run_id = run_id or time.strftime("%Y%m%d-%H%M%S")
    messages = [{"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Prove this theorem:\n\ntheorem {theorem['name']} {theorem['statement']}"}]
    total = {"input": 0, "output": 0}
    record = {}
    for attempt in range(1, max_attempts + 1):
        started = time.time()
        if model == "reference":  # offline check of the pipeline, no API
            reply, tokens = theorem["reference"], {"input": 0, "output": 0}
        else:
            client = client or make_client()
            reply, tokens = ask_model(client, model, messages)
        proof = clean_proof(reply)
        verified, lean_output = check_with_lean(theorem, proof)
        total = {k: total[k] + tokens[k] for k in total}
        record = {"run_id": run_id, "model": model, "theorem": theorem["name"],
                  "group": theorem["group"], "attempt": attempt, "proof": proof,
                  "verified": verified, "lean_output": lean_output[:2000],
                  "tokens": tokens, "seconds": round(time.time() - started, 2)}
        log(record)
        if on_attempt:
            on_attempt(record)
        if verified:
            break
        messages += [{"role": "assistant", "content": reply},
                     {"role": "user", "content": "Lean rejected that proof with:\n\n"
                      f"{lean_output[:1500]}\n\nFix it. Return only the proof."}]
    return {"theorem": theorem["name"], "model": model, "verified": record.get("verified", False),
            "attempts": record.get("attempt", 0), "proof": record.get("proof", ""),
            "tokens": total, "cost": cost_of(model, total)}


def summarize(path: Path = RESULTS_FILE) -> list[dict]:
    """Per model: latest result for each theorem → pass rate, avg attempts, tokens, cost."""
    if not path.exists():
        return []
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    finals: dict[tuple, dict] = {}
    spent: dict[tuple, dict] = {}
    for r in rows:
        key = (r["model"], r["theorem"])
        finals[key] = r  # later lines win → latest attempt of latest run
        s = spent.setdefault(key, {"input": 0, "output": 0})
        s["input"] += r["tokens"]["input"]
        s["output"] += r["tokens"]["output"]
    table: dict[str, dict] = {}
    for (model, _), r in finals.items():
        t = table.setdefault(model, {"model": model, "theorems": 0, "verified": 0,
                                      "attempts": 0, "input": 0, "output": 0})
        t["theorems"] += 1
        t["verified"] += int(r["verified"])
        t["attempts"] += r["attempt"]
        t["input"] += spent[(model, r["theorem"])]["input"]
        t["output"] += spent[(model, r["theorem"])]["output"]
    out = []
    for t in table.values():
        cost = cost_of(t["model"], {"input": t["input"], "output": t["output"]})
        out.append({"Model": t["model"],
                    "Verified": f"{t['verified']}/{t['theorems']}",
                    "Pass rate": f"{100 * t['verified'] / t['theorems']:.0f}%",
                    "Avg attempts": round(t["attempts"] / t["theorems"], 2),
                    "Tokens": t["input"] + t["output"],
                    "Cost (USD)": "n/a" if cost is None else f"${cost:.4f}"})
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description="A Meta model finds the proof; Lean checks it.")
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("selftest", help="check Lean with the reference proofs (no API)")
    p = sub.add_parser("prove", help="prove one theorem")
    p.add_argument("name")
    b = sub.add_parser("bench", help="prove every theorem")
    for sp in (p, b):
        sp.add_argument("--model", default=DEFAULT_MODEL)
        sp.add_argument("--attempts", type=int, default=5)
    sub.add_parser("summary", help="print results per model")
    args = parser.parse_args()

    if args.cmd == "selftest":
        ok = 0
        for t in load_theorems():
            verified, out = check_with_lean(t, t["reference"])
            ok += verified
            print(f"{'PASS' if verified else 'FAIL'}  {t['name']}" + ("" if verified else f"\n{out}"))
        print(f"\n{ok}/{len(load_theorems())} reference proofs verified by Lean.")
        return

    if args.cmd == "summary":
        for row in summarize():
            print(" | ".join(f"{k}: {v}" for k, v in row.items()))
        return

    theorems = [get_theorem(args.name)] if args.cmd == "prove" else load_theorems()
    client = None if args.model == "reference" else make_client()
    run_id = time.strftime("%Y%m%d-%H%M%S")
    for t in theorems:
        def show(r):
            mark = "VERIFIED" if r["verified"] else "rejected"
            print(f"  attempt {r['attempt']}: {mark}  ({r['seconds']}s)  {r['proof'][:80]}")
        print(f"\n{t['name']}  [{args.model}]")
        result = prove(t, args.model, args.attempts, client, on_attempt=show, run_id=run_id)
        print(f"  → {'✓ verified' if result['verified'] else '✗ not proved'} in {result['attempts']} attempt(s)")
    print()
    for row in summarize():
        print(" | ".join(f"{k}: {v}" for k, v in row.items()))


if __name__ == "__main__":
    main()
